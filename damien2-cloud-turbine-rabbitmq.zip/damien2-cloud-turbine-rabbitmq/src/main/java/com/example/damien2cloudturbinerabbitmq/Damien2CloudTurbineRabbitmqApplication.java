package com.example.damien2cloudturbinerabbitmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Damien2CloudTurbineRabbitmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(Damien2CloudTurbineRabbitmqApplication.class, args);
	}

}
