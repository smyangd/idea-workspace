package com.example.damien2cloudzuulgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Damien2CloudZuulGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(Damien2CloudZuulGatewayApplication.class, args);
	}

}
