package com.example.damien2cloudturbinehttp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Damien2CloudTurbineHttpApplication {

	public static void main(String[] args) {
		SpringApplication.run(Damien2CloudTurbineHttpApplication.class, args);
	}

}
